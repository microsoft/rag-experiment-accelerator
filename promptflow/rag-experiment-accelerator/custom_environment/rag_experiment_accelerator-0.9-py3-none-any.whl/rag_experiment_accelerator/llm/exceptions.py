class ContentFilteredException(Exception):
    pass
